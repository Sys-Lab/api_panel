﻿//SYSLIB.eror errorcede
//ver 20130328.02
//last modified: scientihark
SYSLIB_error.list={
	10000:"测试数据 %s0,%s1,%s2,%s3",
	10001:"测试数据2 %s0,%s1,%s2",  
	10002:"亲，%s0 刚刚说 %s1"
};










